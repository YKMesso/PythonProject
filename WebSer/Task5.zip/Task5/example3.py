import graphene
import requests
import json

class Product(graphene.ObjectType):
    id = graphene.Int()
    title = graphene.String()
    cost = graphene.Decimal()


class Query(graphene.ObjectType):

    product = graphene.Field(Product)
    def resolve_product(root, info):

        data = requests.get('http://127.0.0.1:5000/getProducts')
        print(data.text)

        '''

        This is a sample for what API will return
        {
        "id": "1221"
        }    
    
        '''

        json_content = json.loads(data.text)
        print(json_content)

        extractedId = json_content['id']

        print(extractedId)
        return Product(id=extractedId)

schema = graphene.Schema(query=Query)
query = '''
    {
    product {
    id
    title
    }
    }
'''

result = schema.execute(query)
print(result)


