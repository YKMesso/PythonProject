import graphene
from flask import Flask
from flask_restful import Resource, Api
import json


app = Flask(__name__)
api = Api(app)

class getProducts(Resource):
    def get(self):
        return {'id': '1221'}

class getStudents(Resource):
    def get(self):
        return {'name':'John Smith', 'dob':'01-11-1970',
                'address':'7 the maple, Forest town, Dublin 15',
                'telephone':'8222666', 'email':'johnsmith@test.com'}


api.add_resource(getProducts, '/getProducts')
api.add_resource(getStudents, '/getStudents')

if __name__ == '__main__':
    app.run(debug=True)