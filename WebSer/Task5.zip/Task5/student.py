import graphene
import requests
import json

class Student(graphene.ObjectType):
    name = graphene.String()
    dob = graphene.Date()
    address = graphene.String()
    telephone = graphene.String()
    email = graphene.String()

class Query(graphene.ObjectType):
    student = graphene.Field(Student)
    def resolve_student(self, info):

        data = requests.get('http://127.0.0.1:5000/getStudents')
        print(data.text)

        json_content = json.loads(data.text)
        print(json_content)

        extractedId = json_content['id']

        print(extractedId)
        return Student(id=extractedId)

        #return Student(name="John Smith", dob="01-11-1970", address="7 the maple, Forest town, Dublin 15", telephone="8222666", email="johnsmith@test.com")

schema = graphene.Schema(query=Query)
query = """
{
    student{
        name
        dob
        address
        telephone
        email
    }
}
"""

result = schema.execute(query)
print(result)